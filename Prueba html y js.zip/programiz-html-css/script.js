// Ejercicio 1, calcular la edad al poner el año

let num = prompt("¿En que año naciste? ");
let anio = 2025;
let cal = anio - num;
console.log("Tu edad es " + cal);

// Ejercicio 2, suma de numeros pares, escribe un bucle que sume todo los numeros pares del 1 al 100

let par = [];
for (let i = 0; i <= 100; i++)
if (i % 2 == 0) {
    par.push(i)
}
else {
}
let total = par.reduce((a, b) => a + b, 0);
console.log(total);

// Ejercicio 3 cree un programa que solicite al usuario un numero y muestre la tabla de multiplicar de ese numero del 1 al 10

let num2 = prompt("¿Que numero desea ver la tabla? ");
num2 = parseInt(num2);
for (var i = 0; i <= 10; i++) {
    var mult = num2 * i
    console.log(mult)
}

// Ejercicio 4 crea una lista ordenada y una no ordenada en HTML de tu comida favorita



// Ejercicio 5 crea una tabla con la informacion de los 14 alumnos del salon, nombre, edad y cedula HTML

// Ejercicio 6 Crea una funcion donde el usuario ponga un numero e identifique si es par o impar

function pares() {
    var impar = prompt("Numero a comprobar ")
    if (impar%2 == 0) {
        console.log("Tu numero es par")
    }
    else {
        console.log("Tu numero es impar")
    }
}
pares()